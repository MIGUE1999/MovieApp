//
//  HomeViewModel.swift
//  MovieApp
//
//  Created by Tejada Ortigosa Miguel Angel on 7/8/23.
//

import Foundation


final class HomeViewModel{
    
    private let movieStore: MovieService
    
    init(movieStore: MovieService){
        self.movieStore = movieStore
    }
    
    func fetchMovie(id: Int){

        movieStore.fetchMovie(id: 346698) { data in
            
            try {
                let movieTitle = data.get().title
            }
            
        }
        
    }
}
