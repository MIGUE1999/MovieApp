//
//  Movie.swift
//  MovieApp
//
//  Created by Tejada Ortigosa Miguel Angel on 7/8/23.
//

import Foundation

struct MovieResponse: Decodable {
    let results: [Movie]
}

struct Movie: Decodable {
    let id: Int
    let title: String
    let backDropPath: String?
    let posterPath: String?
    let overview: String
    let voteAverage: Double
    let voteCount: Int
    
    var backdropURL: URL {
        return URL(string: "https://image.tmdb.org/t/p/w500\(backDropPath ?? "")")!
    }
}


